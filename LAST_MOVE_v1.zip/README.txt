LAST MOVE: STREET SURVIVOR v1
Playable browser prototype.

CONTROLS
- Mobile: drag the joystick to walk, tap ACTION near a building.
- Desktop: WASD/arrow keys + ACTION.
- Career: choose one main career. Changing careers costs money, reputation and a full day.
- Rent: automatically charged every 3 days.
- Save: stores progress in the browser.

IMPORTANT
Some iPhone Files previews display HTML as text instead of executing JavaScript.
For the game to run, open index.html in a real browser/server environment.
This package is a playable prototype, not yet a store-ready native APK/IPA.
